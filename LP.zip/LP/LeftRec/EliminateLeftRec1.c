#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc , char * argv[])
{
	FILE * fp = fopen(argv[1],"r");
	FILE * ofp = fopen("output.c", "w");
	char buff[1024];

	while(fgets(buff, 1024, fp) != NULL)
		fprintf(ofp, "%s",buff+3 );
}