#include <stdio.h>
#include <unistd.h>

int  main()
{
	int i = 0;
	FILE * fp = fopen("input.txt","w");



	while(i < 20)
	{
		sleep(1);
		if(i % 2 == 0 )
			fprintf(fp, "%d\n", i);
		i++;

	}
}