#include <stdio.h>
#define MAX 10 
#define MIN 2 
#define MORE min
#define MINMAX MAX

int main()
{
	int array[MAX];
	int array2[MIN];
	int MINMAX ;
	printf("MIN %d , max %d", MAX , MAX);
	printf("MORE MORE %s", MORE );
	printf("%s\nMIN",MIN);
	return 0 ;
}