#include <stdio.h>
 
 int main()
 {
 	int array[10];
 	int array2[2];
 	int MAX ;
 	printf( "MIN %d , max %d", 10 , 10);
 	printf( "MORE MORE %s", min );
 	printf( "%s\nMIN",2);
 	return 0 ;
 } 